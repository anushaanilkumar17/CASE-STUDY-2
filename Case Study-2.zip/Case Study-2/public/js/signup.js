function validate() {
    let name = document.getElementById("name");
    let email = document.getElementById("email");
    let number = document.getElementById("number");
    let pwd= document.getElementById("pwd");
    let cnfpwd = document.getElementById("cnfpwd");

             let namecheck= /^([A-Za-z. ]{3,30})$/;
             let emailcheck = /^([A-Za-z0-9\.-]+)@([A-Za-z0-9\-]+).([a-z]{2,3})(.[a-z]{2,3}?)$/;
             let pwdcheck = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
             let numbercheck = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
      
//Name validation starts here//

                    if(namecheck.test(name.value)){
                    document.getElementById('nameerror').innerHTML="";
                    }

                    else{
                    document.getElementById('nameerror').innerHTML="**Name is Invalid**";
                    document.getElementById('nameerror').style.color = "red";
                    document.getElementById('nameerror').style.fontSize = "12px";
                    document.getElementById('nameerror').style.fontFamily = "Verdana, Geneva, Tahoma, sans-serif"
                    return false;
                    }

//Email validation starts here//

                    if (emailcheck.test(email.value)){
                    document.getElementById('emailerror').innerHTML="";
                    }

                     else{
                    document.getElementById('emailerror').innerHTML="**Email ID is Invalid**";
                    document.getElementById('emailerror').style.color = "red";
                    document.getElementById('emailerror').style.fontSize = "12px";
                    document.getElementById('emailerror').style.fontFamily = "Verdana, Geneva, Tahoma, sans-serif"
                    return false;
                    }

// Number Validation starts here//

                    if(numbercheck.test(number.value)){
                    document.getElementById('numbererror').innerHTML="";
                    }

                    else{
                    document.getElementById('numbererror').innerHTML="**Number is Invalid**";
                    document.getElementById('numbererror').style.color = "red";
                    document.getElementById('numbererror').style.fontSize = "12px";
                    document.getElementById('numbererror').style.fontFamily = "Verdana, Geneva, Tahoma, sans-serif";
                    return false;
                    }

//Password validation starts here//

                    if (pwdcheck.test(pwd.value)){
                    document.getElementById('pwderror').innerHTML="";
                    }

                    else{
                    document.getElementById('pwderror').innerHTML="**Password is Invalid";
                    document.getElementById('pwderror').style.color = "red";
                    document.getElementById('pwderror').style.fontSize = "12px";
                    document.getElementById('pwderror').style.fontFamily = "Verdana, Geneva, Tahoma, sans-serif"
                    return false;
                    }

//confirm-password validation starts here//
         
            
                    if (cnfpwd.value == "") {
                    document.getElementById('pwderror').innerHTML = "**Please confirm your password**";
                    document.getElementById('pwderror').style.color = "red";
                    document.getElementById('pwderror').style.fontSize = "12px";
                    document.getElementById('pwderror').style.fontFamily = "Verdana, Geneva, Tahoma, sans-serif"
                    return false;
                    }

                    else if (pwd.value != cnfpwd.value){
                    document.getElementById('cnfpwderror').innerHTML = "**Password does not match**";
                    document.getElementById('cnfpwderror').style.color = "red";
                    document.getElementById('cnfpwderror').style.fontSize = "12px";
                    document.getElementById('cnfpwderror').style.fontFamily = "Verdana, Geneva, Tahoma, sans-serif";
                    return false;
                    }

                    else (cnfpwd.value);{
                    document.getElementById('cnfpwderror').innerHTML = "";
                  
                    }

                    document.getElementById('pwderror').innerHTML = "**Login Successfull**";
                    document.getElementById('pwderror').style.color = "green";
                    document.getElementById('pwderror').style.fontSize = "14px";
                    return true;
  }
  

// Password Checker starts here //

    let pass= document.getElementById('pwd');
    
    pass.addEventListener('keyup',function(){
    checkPassword(pwd.value)
    })

              function checkPassword(password){

                var prog = document.getElementById('progs');
                var strengthBar = document.getElementById('strength');
                var strength=0;

                if(password.match(/[a-z]/))
                {
                  strength += 1;
                }
                
                if((password.length>=6)&&(password.match(/[!\@\#\$\%\^\&\*\?\-\_\>\<\.\,]/)))
                {
                  strength += 1;
              
                }
            
                if((password.length>=8)&&(password.match(/[a-z]/))&&(password.match(/[A-Z]/))&&(password.match(/[0-9]/)))
                {
                  strength += 1;
              
                }
                switch(strength)
                {
                  case 0: strengthBar.style.width='0%';
                          prog.style.visibility='visible';
                          document.getElementById('strgts').style.visibility='hidden';
                          document.getElementById('strgts').style.color='red'
                          break;

                  case 1: strengthBar.style.width='40%';
                          prog.style.visibility='visible';
                          strengthBar.style.backgroundColor='red';
                          document.getElementById('strgts').style.visibility='visible';
                          document.getElementById('strgts').innerText="Poor";
                          document.getElementById('strgts').style.color='red';
                          break;

                  case 2: strengthBar.style.width='80%';
                          prog.style.visibility='visible';
                          strengthBar.style.backgroundColor='orange';
                          document.getElementById('strgts').style.visibility='visible';
                          document.getElementById('strgts').innerText="Medium";
                          document.getElementById('strgts').style.color='orange';
                          break;
                          
                  case 3: strengthBar.style.width='100%';
                          prog.style.visibility='visible';
                          strengthBar.style.backgroundColor='green';
                          document.getElementById('strgts').style.visibility='visible';
                          document.getElementById('strgts').innerText="Strong";
                          document.getElementById('strgts').style.color='green';
                          break;

              }

            }