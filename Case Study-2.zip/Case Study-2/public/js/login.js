let email = document.getElementById("email");
let pwd = document.getElementById("password");


function validate() {
      
 let emailcheck = /^([A-Za-z0-9\.-]+)@([A-Za-z0-9\-]+).([a-z]{2,3})(.[a-z]{2,3}?)$/;
 let pwdcheck = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;

//email validation starts here//

    if (emailcheck.test(email.value)){
        document.getElementById('emailerror').innerHTML="";
    }

    else{
        document.getElementById('emailerror').innerHTML="**Email ID is Invalid**";
        document.getElementById('emailerror').style.color = "red";
        document.getElementById('emailerror').style.fontSize = "12px";
        document.getElementById('emailerror').style.fontFamily = "Verdana, Geneva, Tahoma, sans-serif"
        return false;
    }

//password validation starts here//

    if (pwdcheck.test(pwd.value)){
        document.getElementById('pwderror').innerHTML="";
    }

    else{
        document.getElementById('pwderror').innerHTML="**Password is Invalid";
        document.getElementById('pwderror').style.color = "red";
        document.getElementById('pwderror').style.fontSize = "12px";
        document.getElementById('pwderror').style.fontFamily = "Verdana, Geneva, Tahoma, sans-serif"
        return false;
    }
}