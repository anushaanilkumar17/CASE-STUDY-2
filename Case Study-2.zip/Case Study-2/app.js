const express = require('express');
const app = express();
const nav =
[
    {
        link:'/about',name:'ABOUT US'
    }, 
    
    {
        link:'/books',name:'BOOKS'
    },

    {
        link:'/author',name:'AUTHORS'
    }, 
    
    {
        link:'/contact',name:'CONTACT US'
    },
   
];

const navRight =
[
    {
        Link:'/login',Name:'LOG IN'
    }, 
    
    {
        Link:'/signup',Name:'SIGN UP'
    }
];

const navaddbooks =
[
    {
        LINK:'/admin',NAME:'ADD BOOKS' 
    }
];

const navaddauthor =
[
    {
        LIN:'/adminauthor',NAM:'ADD AUTHOR' 
    }
];

const adminRouter = require('./src/routes/adminRoutes')(nav)
const booksRouter = require('./src/routes/bookRoutes')(nav, navaddbooks)
const aboutRouter = require('./src/routes/aboutRoutes')(nav)
const contactRouter = require('./src/routes/contactRoutes')(nav)
const adminauthorRouter = require('./src/routes/adminauthorRoutes')(nav)
const authorRouter = require('./src/routes/authorRoutes')(nav,navaddauthor)
const loginRouter = require('./src/routes/loginRoutes')(nav)
const signupRouter = require('./src/routes/signupRoutes')(nav)
const updatebookRouter = require('./src/routes/updatebookRoutes')(nav)
const updateauthorRouter = require('./src/routes/updateauthorRoutes')(nav)

app.use(express.urlencoded({extended:true}));
app.use(express.static('./public'));
app.set('view engine','ejs');
app.set('views','./src/views');

app.use('/books',booksRouter);
app.use('/about',aboutRouter);
app.use('/contact',contactRouter);
app.use('/author',authorRouter);
app.use('/login',loginRouter);
app.use('/signup',signupRouter);
app.use('/admin',adminRouter);
app.use('/adminauthor',adminauthorRouter);
app.use('/updatebook',updatebookRouter);
app.use('/updateauthor',updateauthorRouter);

app.get('/',function(req,res){
    res.render("index",
    {  
        nav,
        navRight,
        title: 'HOME || WELCOME TO NATIONAL PUBLIC LIBRARY'
    });
});


app.listen(5000);
