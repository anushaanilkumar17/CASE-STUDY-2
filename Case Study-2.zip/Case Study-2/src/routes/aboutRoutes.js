const express = require('express');
const aboutRouter = express.Router();
function router(nav){


    
    aboutRouter.get('/',function(req,res){
        res.render("about",{
            nav,
            title: 'ABOUT US'
        });
    });
    

return aboutRouter;

}

module.exports = router;  