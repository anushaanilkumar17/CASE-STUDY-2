const express = require('express');
const updatebookRouter = express.Router();
function router(nav){


    
    updatebookRouter.get('/',function(req,res){
        res.render("updatebook",{
            nav,
            title: 'UPDATE BOOKS'
        });
    });
    

return updatebookRouter;

}

module.exports = router;  
