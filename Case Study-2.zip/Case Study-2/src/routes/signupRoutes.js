const express = require('express');
const signupRouter = express.Router();
const Signupdata = require('../model/Signupdata');
function router(nav){


    
    signupRouter.get('/',function(req,res){
        res.render("signup",{
            nav,
            title: 'SIGN UP'
        });
    });
    

    signupRouter.post('/addsignup',function(req,res){

        var item ={
          name:req.body.name,
          email:req.body.email,
          number:req.body.number,
          password:req.body.password,
          cpassword:req.body.cpassword
        }
    
        var signupdetails = Signupdata(item);
        signupdetails.save();
        res.redirect('/login');
        
    });
    


return signupRouter;

}

module.exports = router;  