const express = require('express');
const booksRouter = express.Router();
const Bookdata = require('../model/Bookdata');
function router(nav, navaddbooks){

    // var books = [

    //     {
    //         title:'THE STAND',
    //         author:'AUTHOR: STEPHEN KING',
    //         genre:'GENRE: SCIENCE FICTION',
    //         img:'book 6.jpg',
    //         description:'The Stand is a post-apocalyptic dark fantasy novel written by American author Stephen King and first published in 1978 by Doubleday. The plot centers on a pandemic of a weaponized strain of influenza that kills almost the entire world population.'
    //     },
    
    //     {
    //         title:'RAISE THE TITANIC',
    //         author:'AUTHOR: CLIVE CUSSLER',
    //         genre:'GENRE: ADVENTURE ',
    //         img:'book 39.jpg',
    //         description:'It tells the story of efforts to bring the remains of the ill-fated ocean liner RMS Titanic to the surface of the Atlantic Ocean in order to recover a stockpile of an exotic mineral that was being carried aboard. Raise the Titanic! was the third published book to feature the authors protagonist, Dirk Pitt.'
    //     },
        
    //     {
    //         title:'THE PROTOCOL',
    //         author:'AUTHOR: J.ROBERT KENNEDY',
    //         genre:'GENRE: ACTION',
    //         img:'book 42.jpg',
    //         description:'For two thousand years the Triarii have protected us, influencing history from the crusades to the discovery of America. Descendent from the Roman Empire, they pervade every level of society, and are now in a race with our own government to retrieve an ancient artifact thought to have been lost forever.'
    //     },
     
    //     {
    //         title:'DRACULA',
    //         author:'AUTHOR: BRAM STOKER',
    //         genre:'GENRE: HORROR',
    //         img:'book 25.jpg',
    //         description:'Dracula is an 1897 Gothic horror novel by Irish author Bram Stoker. It introduced the character of Count Dracula and established many conventions of subsequent vampire fantasy.'
    //     },

    //     {
    //         title:'THE LITTLE PRINCE',
    //         author:'AUTHOR: ANTOINE DESAINT',
    //         genre:'GENRE: SHORT STORY',
    //         img:'book 7.jpg',
    //         description:'The Little Prince is a novella written by the French Writer, Antoine De Saint-Exupéry. The story begins with the narrator remembering something he drew as a child. As per the narrator, the drawing consisted of an elephant inside the stomach of a snake.'
    //     },
        
    // ];
    
    
    
    
    booksRouter.get('/',function(req,res){
        Bookdata.find()
        .then(function(books){
            res.render("books",{
                nav,
                navaddbooks,
                title: 'BOOKS',
                books
            
            });
        })
       
    });
    
    booksRouter.get('/:id',function(req,res){
       const id = req.params.id
      Bookdata.findOne({_id: id})
      .then(function(book){
        res.render('book',{
            nav,
            title: 'BOOK',   
            book
            
        });
      })
   
    });

return booksRouter;

}

module.exports = router;
